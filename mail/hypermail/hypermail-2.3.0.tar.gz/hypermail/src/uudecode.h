/*
** uudecode.c function 
*/

int uudecode(FILE *, char *, char *, int *, struct Push *);
