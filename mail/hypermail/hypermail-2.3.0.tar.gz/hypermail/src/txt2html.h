
void
txt2html(FILE *, struct emailinfo *, const struct body *, bool, int);
void init_txt2html(void);
void end_txt2html(FILE *fp);
