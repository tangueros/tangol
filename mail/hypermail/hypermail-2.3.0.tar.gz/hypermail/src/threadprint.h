void print_all_threads(FILE *, int, int, struct emailinfo *);
int isreplyto(int, int);
