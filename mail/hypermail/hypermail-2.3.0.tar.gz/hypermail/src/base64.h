/* 
** MIME Decode - base64.c
*/

void base64Decode(char *, char *, int *);
