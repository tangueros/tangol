void getname(char *, char **, char **);
char *spamify(char *input);
char *spamify_small(char *input);
char *spamify_replacedomain(char *input, char *antispamdomain);
