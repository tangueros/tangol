
#undef HAVE_GDBM_H
